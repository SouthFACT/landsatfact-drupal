﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'is', {
	alt: 'Baklægur texti',
	btnUpload: 'Hlaða upp',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Almennt',
	lockRatio: 'Festa stærðarhlutfall',
	menu: 'Eigindi myndar',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Reikna stærð',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Eigindi myndar',
	uploadTab: 'Senda upp',
	urlMissing: 'Image source URL is missing.' // MISSING
} );
